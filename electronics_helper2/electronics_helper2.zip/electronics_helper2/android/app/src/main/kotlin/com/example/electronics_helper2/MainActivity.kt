package com.example.electronics_helper2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
